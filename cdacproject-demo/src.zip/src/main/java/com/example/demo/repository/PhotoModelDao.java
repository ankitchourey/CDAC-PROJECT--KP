package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Advertise;
import com.example.demo.models.PhotoModel;

@Repository
public class PhotoModelDao {

	@PersistenceContext
	private EntityManager sf;
	
	@Autowired
	PhotoRepository pdao;
	
	@Autowired
	AdvertiseRepository adao;
	
	
	public void addPhotos(List<PhotoModel> list, long id) {
		Advertise a;
		Optional<Advertise> findAdvById = adao.findById(id);
		if(findAdvById.isPresent())
		{
			a=findAdvById.get();
			for (PhotoModel photos : list) {
				System.out.println(photos);
				photos.setAdvertise(a);
				a.getPhotoList().add(photos);
			}
		}
	}
	
	public PhotoModel getPhoto() {
		String jpql = "SELECT p from Photos p WHERE p.photoId=2";
		return sf.unwrap(Session.class).createQuery(jpql,PhotoModel.class).getSingleResult();
	}

	public List<PhotoModel> getPhotosById(long id) {
		String jpql = "SELECT p from Photos p WHERE p.advertise.adv_id=:id";
		return sf.unwrap(Session.class).createQuery(jpql,PhotoModel.class).setParameter("id",id).getResultList();
	}
	
}
