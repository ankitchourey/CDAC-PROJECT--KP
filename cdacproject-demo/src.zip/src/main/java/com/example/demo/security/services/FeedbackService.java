package com.example.demo.security.services;

import com.example.demo.models.Feedback;

public interface FeedbackService {
	Feedback addFeedbackDetails(Feedback f);
}
