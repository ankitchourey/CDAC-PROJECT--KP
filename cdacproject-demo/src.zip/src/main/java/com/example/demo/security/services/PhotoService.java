package com.example.demo.security.services;

import java.util.List;

import com.example.demo.models.PhotoModel;

public interface PhotoService {
	public void addPhotos(List<PhotoModel> list,long id);
	public PhotoModel getPhoto();
	public List<PhotoModel> getPhotosById(long id);
}
