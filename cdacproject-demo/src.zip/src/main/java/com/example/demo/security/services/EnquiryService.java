package com.example.demo.security.services;

import com.example.demo.models.Enquiry;

public interface EnquiryService {
	Enquiry addEnquiry(long userId,long addId,Enquiry enquiry);
	void deleteEnquiry(long userId,long addId,long enquiryId);
}

